"""
Retrain Smart Reminder Models and Upload to HuggingFace

Full workflow in one script:
  1. Download current models from HuggingFace (backup)
  2. Retrain confusion_detection, caregiver_alert, severity_classifier
     using train_reminder_models_pitt.py (with improved class balance settings)
  3. Upload retrained models back to HuggingFace

Usage:
  python scripts/upload_to_huggingface.py

Requirements:
  pip install huggingface_hub
  huggingface-cli login   (run once, paste your HF token)
"""

import subprocess
import sys
import shutil
import json
from pathlib import Path

HF_REPO_ID = "VindiO/dementia-reminder-system"

# Files managed in HuggingFace (reminder system models only — do NOT overwrite GB risk model)
REMINDER_MODEL_FILES = [
    "confusion_detection_model.joblib",
    "caregiver_alert_model.joblib",
    "severity_classifier_model.joblib",
    "optimal_thresholds.json",
    "training_metadata.json",
]

REMINDER_MODELS_DIR = Path("models/reminder_system")


# ─────────────────────────────────────────────────────────────
# STEP 0: Check huggingface_hub is installed
# ─────────────────────────────────────────────────────────────
try:
    from huggingface_hub import HfApi, hf_hub_download
except ImportError:
    print("Installing huggingface_hub...")
    subprocess.check_call([sys.executable, "-m", "pip", "install", "huggingface_hub"])
    from huggingface_hub import HfApi, hf_hub_download

api = HfApi()


# ─────────────────────────────────────────────────────────────
# STEP 1: Backup current HuggingFace models locally
# ─────────────────────────────────────────────────────────────
print("\n" + "=" * 60)
print("STEP 1: Downloading current HF models as backup")
print("=" * 60)

backup_dir = REMINDER_MODELS_DIR / "hf_backup"
backup_dir.mkdir(parents=True, exist_ok=True)

for filename in REMINDER_MODEL_FILES:
    try:
        cached_path = hf_hub_download(repo_id=HF_REPO_ID, filename=filename)
        dest = backup_dir / filename
        shutil.copy(cached_path, dest)
        print(f"  Backed up: {filename}")
    except Exception as e:
        print(f"  WARNING: Could not backup {filename}: {e}")

print(f"\nBackup saved to: {backup_dir}")


# ─────────────────────────────────────────────────────────────
# STEP 2: Retrain models
# ─────────────────────────────────────────────────────────────
print("\n" + "=" * 60)
print("STEP 2: Retraining reminder system models")
print("        (confusion threshold=2.0, alert threshold=3.5,")
print("         SMOTE sampling_strategy=0.5)")
print("=" * 60)

result = subprocess.run(
    [sys.executable, "scripts/train_reminder_models_pitt.py"],
    capture_output=False,   # show live output in terminal
)

if result.returncode != 0:
    print("\nERROR: Training script failed. Aborting upload.")
    print("Your HuggingFace models are unchanged.")
    sys.exit(1)

print("\nTraining completed successfully.")


# ─────────────────────────────────────────────────────────────
# STEP 3: Verify retrained files exist locally
# ─────────────────────────────────────────────────────────────
print("\n" + "=" * 60)
print("STEP 3: Verifying retrained files")
print("=" * 60)

missing = []
for filename in REMINDER_MODEL_FILES:
    local_path = REMINDER_MODELS_DIR / filename
    if local_path.exists():
        size_kb = local_path.stat().st_size / 1024
        print(f"  OK  {filename}  ({size_kb:.1f} KB)")
    else:
        print(f"  MISSING: {filename}")
        missing.append(filename)

if missing:
    print(f"\nERROR: Missing files: {missing}")
    print("Check training output above for errors.")
    sys.exit(1)


# ─────────────────────────────────────────────────────────────
# STEP 4: Upload to HuggingFace
# ─────────────────────────────────────────────────────────────
print("\n" + "=" * 60)
print("STEP 4: Uploading retrained models to HuggingFace")
print(f"        Repo: {HF_REPO_ID}")
print("=" * 60)

upload_errors = []
for filename in REMINDER_MODEL_FILES:
    local_path = REMINDER_MODELS_DIR / filename
    try:
        api.upload_file(
            path_or_fileobj=str(local_path),
            path_in_repo=filename,
            repo_id=HF_REPO_ID,
            repo_type="model",
            commit_message=f"Retrain: improved class balance (confusion>=2.0, alert>=3.5, SMOTE=0.5) - {filename}",
        )
        print(f"  Uploaded: {filename}")
    except Exception as e:
        print(f"  ERROR uploading {filename}: {e}")
        upload_errors.append(filename)

# ─────────────────────────────────────────────────────────────
# Summary
# ─────────────────────────────────────────────────────────────
print("\n" + "=" * 60)
if upload_errors:
    print(f"DONE with errors. Failed uploads: {upload_errors}")
    print(f"Backup of old models is at: {backup_dir}")
else:
    print("ALL DONE — Models retrained and uploaded successfully!")
    print(f"\nChanges applied:")
    print("  - Confusion label threshold: 3.0 → 2.0 (more positive samples)")
    print("  - Alert label threshold:     4.5 → 3.5 (more positive samples)")
    print("  - SMOTE sampling_strategy:   default → 0.5 (better class balance)")
    print(f"\nBackup of old HF models saved at: {backup_dir}")
    print(f"Live repo: https://huggingface.co/{HF_REPO_ID}")
print("=" * 60)
